let s1 = "Swati";
let s2 = "Solanki";
let s3 = s1 + " " + s2;
document.write(s3);
let name=prompt("What is your name?");
document.write(name);

/*
!(function(){
    let name=prompt("What is Your Name!!!");
    document.write(name);
})*/
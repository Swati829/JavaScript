var x = 100;
x += 50;

document.write(x);